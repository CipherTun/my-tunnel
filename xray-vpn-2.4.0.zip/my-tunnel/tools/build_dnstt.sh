#!/usr/bin/env bash
# Builds the upstream dnstt client (https://www.bamsoftware.com/software/dnstt/)
# for the three Android ABIs and installs it as android/app/src/main/jniLibs/<abi>/libdnstt.so.
#
# Why an executable named lib*.so and not a gomobile AAR: the Xray core (flutter_v2ray_client) is
# already a gomobile AAR. Two gomobile AARs both ship lib/<abi>/libgojni.so, so Gradle either fails
# to merge them or silently keeps one and breaks the other. A separate process has no such clash.
# Android extracts lib*.so into the app's native library directory (patch_android.py sets
# useLegacyPackaging), and executables there may be run by the app.
#
# Run after `flutter create` (needs android/). Requires git and Go.
#   DNSTT_REF=<tag-or-branch>   pin a version (default: the repository's default branch)
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="${DNSTT_SRC:-https://www.bamsoftware.com/git/dnstt.git}"
REF="${DNSTT_REF:-}"

[ -d "$ROOT/android/app/src/main" ] || { echo "ERROR: android/ not found; run flutter create first"; exit 1; }
command -v go >/dev/null || { echo "ERROR: Go is not installed"; exit 1; }

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

if [ -n "$REF" ]; then
  git clone --depth 1 --branch "$REF" "$SRC" "$WORK/dnstt"
else
  git clone --depth 1 "$SRC" "$WORK/dnstt"
fi
echo "dnstt commit: $(git -C "$WORK/dnstt" rev-parse HEAD)"
go version

cd "$WORK/dnstt/dnstt-client"

# abi  GOARCH  GOARM  expected `file` text
build() {
  local abi="$1" goarch="$2" goarm="$3" want="$4"
  local dir="$ROOT/android/app/src/main/jniLibs/$abi"
  local out="$dir/libdnstt.so"
  mkdir -p "$dir"
  # Static, no cgo: nothing from the host system is linked in.
  CGO_ENABLED=0 GOOS=linux GOARCH="$goarch" GOARM="$goarm" \
    go build -trimpath -ldflags="-s -w" -o "$out" .
  [ -s "$out" ] || { echo "ERROR: $abi build produced no file"; exit 1; }
  local info
  info="$(file -b "$out")"
  echo "$abi: $info ($(du -h "$out" | cut -f1))"
  case "$info" in
    *"$want"*) ;;
    *) echo "ERROR: $abi binary has the wrong architecture (wanted '$want')"; exit 1 ;;
  esac
}

build arm64-v8a   arm64 ""  "ARM aarch64"
build armeabi-v7a arm   7   "ARM, EABI5"
build x86_64      amd64 ""  "x86-64"

echo "libdnstt.so installed for arm64-v8a, armeabi-v7a, x86_64"
